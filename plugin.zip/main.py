def register(api):
    """Вызывается при загрузке плагина."""
    api.on("connect", on_connect)
    api.on("disconnect", on_disconnect)
    api.on("server_selected", on_server)
    api.log("Auto Switch загружен")

def on_connect(server):
    print(f"[Auto Switch] Подключен к {server['name']}")

def on_disconnect():
    print("[Auto Switch] Отключён")

def on_server(server):
    print(f"[Auto Switch] Выбран сервер: {server['name']}")